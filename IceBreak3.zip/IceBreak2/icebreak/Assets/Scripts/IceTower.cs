using UnityEngine;
using System.Collections;

public class IceTower{
	public Ice ice = null;
	public IceTower next = null;
	
}
