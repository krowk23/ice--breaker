using UnityEngine;
using System.Collections;

public class IceListener : MonoBehaviour {
	public glass wg; 
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnCollisionEnter(Collision collision) {
		if(collision.gameObject.tag=="Ice"){
			GameObject ice=collision.gameObject;
			wg.addIce(ice.GetComponent<Ice>().volume);
			GameObject.Find("Water").transform.position+=new Vector3(0,wg.WaterL*3/2,0);
			Destroy(ice);
		}
	}
}
