﻿/*==============================================================================
            Copyright (c) 2010-2011 QUALCOMM Incorporated.
            All Rights Reserved.
            Qualcomm Confidential and Proprietary
==============================================================================*/


// Helper structure for defining macros.
struct QCARMacros
{
    #region PUBLIC_MEMBER_VARIABLES

    public const string PLATFORM_DLL = "QCARWrapper";

    #endregion // PUBLIC_MEMBER_VARIABLES
}
