using UnityEngine;
using System.Collections;

public class EnterPhoneNumber : MonoBehaviour {
	public Texture PhoneTexture;
	public Texture TextBoxTexture;
	public Texture GoTexture;
	public Texture PressedGoTexture;
	public Texture HoveredGoTexture;
	public Texture BackGround;
	static string PhoneNumber="";
	private GUIStyle GoStyle=new GUIStyle();
	void Start(){
		GoStyle.normal.background=(Texture2D)GoTexture;
		GoStyle.active.background=(Texture2D)PressedGoTexture;
		GoStyle.hover.background=(Texture2D)HoveredGoTexture;
	}
	void OnGUI(){
		if (BackGround&&PhoneTexture&&TextBoxTexture&&GoTexture&&PressedGoTexture&&HoveredGoTexture){
			int w=Screen.width;
			int h=Screen.height;
			GUI.skin.textField.fontSize=(int)(h*0.055);
			print(GUI.skin.textField.fontSize);
			Rect Go=new Rect((float)(w*0.6),(float)(h*0.7),(float)(w*0.4),(float)(h*0.3));
			Rect Card=new Rect((float)(w*0.05),(float)(h*0.1),(float)(w*0.27),(float)(h*0.6));
			Rect TextField=new Rect((float)(w*0.64),(float)(h*0.34),(float)(w*0.265),(float)(h*0.065));
			Rect TextBox=new Rect((float)(w*0.4),(float)(h*0.1),(float)(w*0.6),(float)(h*0.5));
			GUI.DrawTexture(new Rect(0,0,w,h),BackGround);								//BackGround
			GUI.DrawTexture(Card,PhoneTexture);											//PhoneCard
			GUI.DrawTexture(TextBox,TextBoxTexture);									//PhoneCard
			PhoneNumber=GUI.TextField(TextField, PhoneNumber, 10);						//TextField
			if (GUI.Button(Go,"",GoStyle)){												//Go Button
				//send phone number to every one.
			}
		}else Debug.LogError("Texture missing.");
	}
}
