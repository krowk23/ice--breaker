using UnityEngine;
using System.Collections;

public class ChoosePenalty : MonoBehaviour {
	public Texture TruthTexture;
	public Texture PressedTruthTexture;
	public Texture HoveredTruthTexture;
	public Texture AdventureTexture;
	public Texture PressedAdventureTexture;
	public Texture HoveredAdventureTexture;
	public Texture BackGround;
	static int Penalty=0;							//1 -> truth, 2 -> adventure, 0 -> haven't chosen
	private GUIStyle TruthStyle=new GUIStyle();
	private GUIStyle AdventureStyle=new GUIStyle();
	void Start(){
		TruthStyle.normal.background=(Texture2D)TruthTexture;
		TruthStyle.active.background=(Texture2D)PressedTruthTexture;
		TruthStyle.hover.background=(Texture2D)HoveredTruthTexture;
		AdventureStyle.normal.background=(Texture2D)AdventureTexture;
		AdventureStyle.active.background=(Texture2D)PressedAdventureTexture;
		AdventureStyle.hover.background=(Texture2D)HoveredAdventureTexture;
	}
	void OnGUI(){
		if (BackGround&&TruthTexture&&AdventureTexture&&PressedTruthTexture&&PressedAdventureTexture&&HoveredTruthTexture&&HoveredAdventureTexture){
			int w=Screen.width;
			int h=Screen.height;
			GUI.DrawTexture(new Rect(0,0,w,h),BackGround);
			if (GUI.Button(new Rect(0,(h/2)+30,w/2,h/3),"",TruthStyle)){			//Truth Button
				Penalty=1;
			}
			if (GUI.Button(new Rect((w/2),(h/2)+30,w/2,h/3),"",AdventureStyle)){	//Adventure Button
				Penalty=2;
			}
		}else Debug.LogError("Texture missing.");
	}
}