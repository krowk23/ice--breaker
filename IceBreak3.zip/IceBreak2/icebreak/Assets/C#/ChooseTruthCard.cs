using UnityEngine;
using System.Collections;

public class ChooseTruthCard : MonoBehaviour {
	static int CardIndex = 0;						//Which card been chosen.
	private Transform Choice=null;
	private bool play=false;
	void Update () {
		int i = 0;
		//Vector3 up=new Vector3(0,Time.deltaTime,0);
		if(play){
			if(Choice.rotation.eulerAngles.z>=180){
				play=false;
				Choice.rotation=Quaternion.Euler(0,0,175);
				Application.LoadLevel("EnterPhoneNumber");
			}
			Choice.Rotate(0,0,5);
			
			//Choice.position+=up;
		}else if(Input.multiTouchEnabled)
			while (i < Input.touchCount){
				if (Input.GetTouch(i).phase == TouchPhase.Began){
					Ray ray = Camera.main.ScreenPointToRay(Input.GetTouch(i).position);
					RaycastHit hit;
					if (Physics.Raycast(ray,out hit))
						if(hit.transform.parent.gameObject.name=="TruthCard-Phone"){
							play=true;
							Choice=hit.transform.parent;
							CardIndex=1;
						}
				}
				++i;
			}
		else if(Input.GetMouseButtonDown(0)){
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray,out hit))
				if(hit.transform.parent.gameObject.name=="TruthCard-Phone"){
					play=true;
					Choice=hit.transform.parent;
					CardIndex=1;
				}
		}
	}
}
