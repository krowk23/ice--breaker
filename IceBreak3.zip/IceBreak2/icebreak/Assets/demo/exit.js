
function OnGUI () {
	if(GUI.Button(Rect(0,0,100,100),"Exit" )){
												Application.Quit();
	}
}